var script  = document.createElement('script');
script.type = 'text/javascript';
script.src  = 'https://raw.github.com/JNehlsen/ttTools/master/releases/latest/ttTools.extension.min.js';
document.head.appendChild(script);